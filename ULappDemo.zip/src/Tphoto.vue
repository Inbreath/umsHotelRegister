<template>
  <div class="wrapper" @back='backMethod' append="tree">
     <ums-header
      title="取件--photoEnsure" 
      @onLeftPartClick="leftClick"
      class="header">
      </ums-header>

<div class="btn-group" >
   <!--<image class = "new-item"  style="width:600; height:700;" src="./static/001.jpg"> </image>-->
   <image class = "new-item" style="width:500; height:500;" :src = "photourl1"/> </image>
 </div>
        <div class="new-item-group">
          <text class="title-text" >姓名</text>
         <input class="input-text" type="text" v-model="name">
          <text class="title-text"  >电话</text>
         <input class="input-text" type="text" v-model="tel">
          <text class="title-text" >备注</text>
          <input class="input-text" type="text" v-model="remark">
        </div>

   
          <div class="btn" @click="lookPhoto">
            <text class = "btn-text">确认</text>
          </div>
          <div class="btn" @click="cancel">
            <text class = "btn-text">取消</text>
          </div>
       
       <!-- <div class="new-btn-group" >
          <div class="new-btn" @click="start">
            <text class = "new-btn-text">人员管理</text>
          </div>
        </div>
        <div class="new-btn-group" >
        <div class="new-btn" @click="start">
            <text class = "new-btn-text">存放记录</text>
          </div>
       </div> -->
       <!-- <router-view class="view"></router-view> -->
       
  </div>
</template>

<style>
.new-btn-text {
  color: #ffffff;
  justify-content: center;
}
.new-btn {
  width: 600px;
  height: 150px;
  justify-content: center;
  align-items: center;
  padding: 20px 40px;
  margin-top: 100px;
  background-color: #8774e8;

  border-radius: 10px;
  border-width: 1px;
  border-color: #ccc;
  border-style: solid;
}
.new-btn-group {
  justify-content: center;

  flex-direction: row;
}
.btn-group {
  margin-top: 50px;
  flex-direction: row;
  justify-content: center;
}
.btn {
  width: 280px;
  height: 50px;
  align-items: center;
  justify-content: center;
  padding: 40px 40px;
  margin-top: 100px;
  background-color: #8774e8;

  border-radius: 10px;
  border-width: 1px;
  border-color: #ccc;
  border-style: solid;
}
.btn-text {
  color: #ffffff;

  justify-content: center;
}
.wrapper {
  width: 750px;
}
.active {
  flex: 1;
  width: 250px;
  height: 100px;
  justify-content: center;
  align-items: center;
  background-color: green;
}
.test {
  background: #fff;
}
</style>

<script>
import { UmsButton, UmsToast } from "ums-comp";
import { umsHeader } from "ums-comp";
import umsApi from "ums-api";

export default {
  created() {
    umsApi.storage.getItem("photourl", event => {
      var photourl = event.data;
      console.log("dxy+图片路径: " + photourl);
      this.photourl1 = "file://.." + photourl;
      umsApi.storage.getItem("customer_name", event => {
        var customer_name = event.data;
        this.name = customer_name;
        console.log("dxy+顾客姓名: " + customer_name);
        umsApi.storage.getItem("customer_tel", event => {
          var customer_tel = event.data;
          this.tel = customer_tel;
          console.log("dxy+顾客电话: " + customer_tel);
          umsApi.storage.getItem("remark", event => {
            var remark = event.data;
            this.remark = remark;
            console.log("dxy+备注: " + remark);
          });
        });
      });
    });
  },

  components: {
    UmsHeader: umsHeader
  },
  data: {
    index: 1,
    photourl1: "",
    name: "",
    tel: "",
    remark: ""
  },
  methods: {
    lookPhoto() {
      umsApi.storage.getItem("deposit_id", event => {
        var deposit_id = event.data;
        console.log("dxy订单号" + deposit_id);
        umsApi.storage.getItem("Verificationtype", event => {
          var Verificationtype = event.data;
          console.log("dxy验证方式" + Verificationtype);
          umsApi.storage.getItem("password", event => {
            var password = event.data;
            console.log("dxy密码" + password);
            if (Verificationtype == "1") {
              umsApi.callApps(
                {
                  pkgName: "com.umszjpay.verification",
                  activity: "com.umszjpay.verification.MainActivity",
                  transData: {
                    transType: 1002,
                    transData: {
                      isNeedVerify: false
                    }
                  }
                },
                ret => {
                  var result = JSON.parse(ret);
                  var data = JSON.parse(result.data);
                  var idCard = JSON.parse(data.idCardString);
                  if (idCard != null && idCard != undefined) {
                    var idCardnumber = idCard.number;
                    if (idCardnumber == password) {
                      console.log("dxy验证成功");
                      umsApi.openDB(ret => {
                        if (ret === null || ret === undefined);
                        console.log("dxy打开数据库成功");
                      });
                      umsApi.executeSql(
                        "update  t_deposit set isrefund = '1' where deposit_id = ?",
                        [deposit_id],
                        ret => {
                          console.log("dxy+SQL batch result: " + ret);
                          var data = JSON.parse(ret.substr(1, ret.length - 2));
                          umsApi.closeDB(ret => {
                            if (ret === null || ret === undefined)
                              console.log("dxy+关闭数据库成功");
                            if (data.type == "success") {
                              umsApi.navigator.push({ url: "success.js" });
                            } else {
                              console.log("dxy系统异常");
                              umsApi.navigator.push({ url: "error.js" });
                            }
                          });
                        }
                      );
                    } else {
                      console.log("dxy验证失败");
                      umsApi.navigator.push({ url: "fail.js" });
                    }
                  }
                }
              );
            } else if (Verificationtype == "2") {
              umsApi.callTrans(
                {
                  appName: "公共资源",
                  bizName: "余额查询",
                  transData: {}
                },
                ret => {
                  var result = JSON.parse(ret);
                  var transData = result.transData;
                  if (transData != null && transData != undefined) {
                    var cardNo = transData.cardNo;
                    if (cardNo == password) {
                      console.log("dxy验证成功");
                      umsApi.openDB(ret => {
                        if (ret === null || ret === undefined);
                        console.log("dxy打开数据库成功");
                      });
                      umsApi.executeSql(
                        "update  t_deposit set isrefund = '1' where deposit_id = ?",
                        [deposit_id],
                        ret => {
                          console.log("SQL batch result: " + ret);
                          var data = JSON.parse(ret.substr(1, ret.length - 2));
                          umsApi.closeDB(ret => {
                            if (ret === null || ret === undefined)
                              console.log("dxy+关闭数据库成功");
                            if (data.type == "success") {
                              umsApi.navigator.push({ url: "success.js" });
                            } else {
                              console.log("dxy系统异常");
                              umsApi.navigator.push({ url: "error.js" });
                            }
                          });
                        }
                      );
                    } else {
                      console.log("dxy验证失败");
                      umsApi.navigator.push({ url: "fail.js" });
                    }
                  }
                }
              );
            } else {
              umsApi.storage.setItem("deposit_id", deposit_id, event => {
                umsApi.storage.setItem("password", password, event => {
                  umsApi.navigator.push({ url: "TakeBypassword.js" });
                });
              });
            }
          });
        });
      });
    },
    cancle() {
       umsApi.navigator.push({url: 'Tdepositid.js'})
    }
  }
};
</script>
