
import mainPageEntry from './entry/mainPageEntry.vue';

const routes = [
  {path:'/mainPageEntry',component:mainPageEntry}
];
export default routes
