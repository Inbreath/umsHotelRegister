<template>
  <div class="wrapper" @back='backMethod' append="tree">
        <div class="btn-group" >
          <div class="btn" @click="keep">
            <text class = "btn-text">存件</text>
          </div>
          <div class="btn" @click="take">
            <text class = "btn-text">取件</text>
          </div>
        </div>
       
    
        <div class="new-btn-group" >
        <div class="new-btn" @click="start">
            <text class = "new-btn-text">存放记录</text>
          </div>
       </div>
       <!-- <router-view class="view"></router-view> -->
  </div>
</template>

<style>
.new-btn-text{
    color: #ffffff;    
    justify-content: center;
  }
  .new-btn{
    width: 600px;
    height: 150px;
    justify-content: center;
    align-items: center;
    padding: 20px 40px;
    margin-top: 100px;
    background-color: #8774E8;
    
    border-radius: 10px;
    border-width:1px;
    border-color: #ccc;
    border-style: solid ; 
  }
  .new-btn-group{
    justify-content: center;

    flex-direction: row;
  }
  .btn-group{
    flex-direction: row;
    justify-content: center;
  }
  .btn{
    width: 280px;
    height: 280px;
    align-items: center;
    justify-content: center;
    padding: 40px 40px;
    margin-top: 100px;
    background-color: #8774E8;
    
    border-radius: 140px;
    border-width:1px;
    border-color: #ccc;
    border-style: solid ; 
  }
   .btn-text{
    color: #ffffff;
    
    justify-content: center;

  }
  .wrapper { 
    width:750px;
  }
  .active{
    flex:1;
    width: 250px;
    height: 100px;
    justify-content:center;
    align-items:center;
    background-color: green;
  }
  .test{
    background: #fff;
  }
</style>

<script>
  import {UmsButton, UmsToast} from 'ums-comp';
  import {umsHeader} from 'ums-comp';
  import umsApi from 'ums-api';
  Vue.prototype.umsApi = umsApi;

  export default {
    created(){
      // this.jump('/food');
    },
 
    components:{
      UmsHeader: umsHeader
    },
    data: {
      index:1,
    },
    methods:{
      leftClick() {
        umsApi.navigator.pop();
      },
      keep() {
        umsApi.camera.captureImage(
          ret=>{ 
          console.log(  'result: ' +JSON.stringify(  ret )) 

          //this.whichAction ="1:"+"-2:"+JSON.stringify(ret)+"-3:"+ret;
          //var result = JSON.stringify(ret);
          if(ret!=""&&ret!=null){
             var path = ret.path;
             umsApi.storage.setItem('photourl', path, event => {
              umsApi.navigator.push({url: 'photoEnsurePage.js'})
             })
          }else{
            umsApi.navigator.push({url: 'index.js'})
          }
          } 

        ) 

         //umsApi.navigator.push({url: 'photoTakePage.js'})
      },
      take() {
         umsApi.navigator.push({url: 'Tdepositid.js'})
      }
    }
  }
</script>
