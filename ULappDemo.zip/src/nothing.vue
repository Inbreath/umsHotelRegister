<template>
  <div class="wrapper" @back='backMethod' append="tree">
<ums-header
      title="订单号输入错误" 
      @onLeftPartClick="leftClick"
      class="header">
      </ums-header>
       <div class="page">
    <scroller class="main">
      <div class="item">
        <div class="new-item-group">
          <text class= "new-item">订单号输入错误或已被取走</text>
        </div>


        <div class="btn-group">
          <div class="btn" @click="back">
            <text class="btn-text">返回主页面</text>
          </div>
        </div>
      </div>
    </scroller>
  </div>
 </div>
</template>

<style>
.new-btn-text {
  color: #ffffff;
  justify-content: center;
}
.new-btn {
  width: 600px;
  height: 150px;
  justify-content: center;
  align-items: center;
  padding: 20px 40px;
  margin-top: 100px;
  background-color: #8774e8;

  border-radius: 10px;
  border-width: 1px;
  border-color: #ccc;
  border-style: solid;
}
.new-btn-group {
  justify-content: center;

  flex-direction: row;
}
.btn-group {
  flex-direction: row;
  justify-content: center;
}
.btn {
  width: 280px;
  height: 280px;
  align-items: center;
  justify-content: center;
  padding: 40px 40px;
  margin-top: 100px;
  background-color: #8774e8;

  border-radius: 140px;
  border-width: 1px;
  border-color: #ccc;
  border-style: solid;
}
.btn-text {
  color: #ffffff;

  justify-content: center;
}
.wrapper {
  width: 750px;
}
.active {
  flex: 1;
  width: 250px;
  height: 100px;
  justify-content: center;
  align-items: center;
  background-color: green;
}
.test {
  background: #fff;
}
</style>

<script>
import { UmsButton, UmsToast } from "ums-comp";
import { umsHeader } from "ums-comp";
import umsApi from "ums-api";

export default {
  created() {},

  components: {
    UmsHeader: umsHeader
  },
  data: {
    index: 1
  },
  methods: {
    back() {
      umsApi.navigator.push({ url: "index.js" });
    }
  }
};
</script>
